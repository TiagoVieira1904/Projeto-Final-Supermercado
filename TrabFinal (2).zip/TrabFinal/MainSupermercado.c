/*
 * MainSupermercado.c
 */

#include "Supermercado.h"

#define MAX_LINHA		64

void invalidos(void){
	printf("Dados invalidos.\n");
}

void naoPode(void){
	printf("Nao pode fazer isso.\n");
}

//cmd '?'
void cmdAjuda(Supermercado s, string args){
	char lixo[MAX_LINHA];
	if (sscanf(args, "%s", lixo) > 0)
		invalidos();
	else {
		printf("  ? - Ajuda\n");
		printf("  C - Cliente novo\n");
		printf("  D x p n - Cliente coloca produto no cesto\n");
		printf("  E - lista Clientes\n");
		printf("  P p n c g - Produto novo\n");
		printf("  Q p n - reabastecimento de Produto.\n");
		printf("  R - lista Produtos em stock\n");
		printf("  X x n - cliente vai para uma Caixa\n");
		printf("  Y x - cliente vai para a melhor Caixa\n");
		printf("  Z - lista Caixas\n");
		printf("  H - lista Historico\n");
		printf("  T s - avanca Tempo\n");
		printf("  F - Fecha o supermercado e termina o programa\n");
		printf("  . - Termina o programa imediatamente\n");
	}
}

//cmd 'P'
void cmdProdutoNovo(Supermercado s, string args){
	char nome[MAX_LINHA], lixo[MAX_LINHA];
	int quantidade, preco, peso;
	if (sscanf(args,"%s %d %d %d %s", nome, &quantidade, &preco, &peso, lixo) != 4
	|| quantidade < 0 || preco < 0 || peso < 0)
		invalidos();
	else {
		 Produto p= produtoNovoSupermercado(s,nome,quantidade,preco,peso);
         if(p==NULL) {
             naoPode();
         } else {
             printf("Cria o novo produto %s\n", nomeProduto(p));
         }
	}
}

//cmd 'Q'
void cmdReabastecerProdutosStock(Supermercado s, string args){
  char nome[MAX_LINHA], lixo[MAX_LINHA];
    int quant;

    if (sscanf(args, "%s %d %s", nome, &quant, lixo) != 2 || quant <= 0) {
        naoPode();
        return;
    }
 if (!reabastecerStockSupermercado(s, nome, quant)) {
        naoPode();
    }
    else
        printf("Reabastece o produto %s\n", nome);
}

//cmd 'R'
void cmdListarProdutosStock(Supermercado s, string args){
   char lixo[MAX_LINHA];
    if (sscanf(args, "%s", lixo) > 0)
        invalidos();
    else {
   printf("-- Stock -- \n");
  Iterador it= iteradorProdutosSupermercado(s);
   if(!temSeguinteIterador(it))
      printf("  vazio \n");
   while(temSeguinteIterador(it)){
    Produto p=seguinteIterador(it);
      printf("Produto %s: %d unidades, %d centimos, %d gramas \n",nomeProduto(p),quantidadeProduto(p),precoProduto(p),pesoProduto(p));
   }
    destroiIterador(it);
}
}

//cmd 'C'
void cmdClienteNovo(s,args){
  char lixo[MAX_LINHA];
    if (sscanf(args, "%s", lixo) > 0)
        invalidos();
    else{
        Cliente c=clienteNovoSupermercado(s);
        if(c==NULL) return semMemoria();
        printf("Chega o cliente %d\n", obterNumCliente(c));
    }
}

//cmd 'E'
void cmdListarClientesEProdutos(Supermercado s, string args) {
    char lixo[MAX_LINHA];
    if (sscanf(args, "%s", lixo) > 0) {
        invalidos();
        return;
    }

    printf("-- Clientes --\n");
    Iterador it = iteradorClientesSupermercado(s);

    if (!temSeguinteIterador(it)) {
        printf("  vazio\n");
        destroiIterador(it);
        return;
    }

    while (temSeguinteIterador(it)) {
        Cliente c = seguinteIterador(it);
        printf("Cliente %d:\n", obterNumCliente(c));

        if (clienteTemCestoVazioSupermercado(s, c)) {
            printf("  vazio\n");
        } else {
            Iterador itr = iteradorProdutosCestoClienteSupermercado(s, c);
            if (itr != NULL) {
                while (temSeguinteIterador(itr)) {
                    Produto p = seguinteIterador(itr);
                    printf("  Produto %s: %d unidades, %d centimos, %d gramas\n",
                        nomeProduto(p), quantidadeProduto(p), precoProduto(p), pesoProduto(p));
                }
                destroiIterador(itr);
            }
        }
    }
    destroiIterador(it);
}

//cmd 'D'
void cmdAdicionarProdutoCesto(Supermercado s, string args) {
    char nomeProd[MAX_LINHA], lixo[MAX_LINHA];
    int numCliente, quantidade;

    int n = sscanf(args, "%d %s %d %s", &numCliente, nomeProd, &quantidade, lixo);
    if (n < 3 || numCliente < 0) {
        naoPode();
        return;
    }
    if (n == 4) { // argumento extra inválido
        naoPode();
        return;
    }

    if (!adicionaCestoSupermercado(s, numCliente, nomeProd, quantidade)) {
        naoPode();
        return;
    }

    printf("Acrescenta %s\n", nomeProd);
}

//cmd '.'
void cmdFimImediato(Supermercado s, string args){
	printf("Obrigado. Volte sempre!\n");
}

char lerComando(string linha) {
	printf("> ");
	if (fgets(linha, MAX_LINHA, stdin) == NULL)
		linha[0] = '.';
	return toupper(linha[0]);
}

void interpretador(Supermercado s){
	char linha[MAX_LINHA], cmd;
	string args = linha + 2;
	do {
		cmd = lerComando(linha);
		switch (cmd){
			case '?': cmdAjuda(s, args); break;
			case 'P': cmdProdutoNovo(s, args); break;
			case '.': cmdFimImediato(s, args); break;
			case 'R': cmdListarProdutosStock(s,args);  break;
            case 'Q': cmdReabastecerProdutosStock(s,args);  break;
            case 'C': cmdClienteNovo(s,args); break;
            case 'E': cmdListarClientesEProdutos(s,args); break;
            case 'D': cmdAdicionarProdutoCesto(s,args); break;

			case '\n': break;
			default: printf("Comando invalido.\n"); break;
		}
	} while (cmd != 'F' && cmd != '.');
}

int main(void){
	Supermercado super = criaSupermercado();
	interpretador(super);
	destroiSupermercado(super);
	return 0;
}

