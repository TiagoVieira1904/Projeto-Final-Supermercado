#include "Util.h"
#include "Info.h"
#include "Produto.h"
#include "Sequencia.h"
#include "Iterador.h"

#ifndef STOCK_H
#define STOCK_H
typedef struct Stock *Stock;

Stock criaStock();
int reabastecerStock(Stock st, string nome, int quant);
void destroiTudoStock(Stock st);
Iterador iteradorProdutosStock(Stock st);
Produto produtoNovoStock(Stock st, Produto p);
Produto obterProdutoStock(Stock s, string nome);

// Operações universais
void destroiStock(Stock st);

#endif
