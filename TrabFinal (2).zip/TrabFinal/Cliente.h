#include "Util.h"
#include "Info.h"
#include "Stock.h"
#include "Produto.h"
#include "Dicionario.h"
#ifndef CLIENTE_H
#define CLIENTE_H
typedef struct Cliente *Cliente;

Cliente criaCliente();
void adicionarProdutoCesto(Cliente c,Produto p,int quantidade);
int obterQuantidadeCestoCliente(Cliente c, Produto p);
int obterNumCliente(Cliente c);
bool clienteTemCestoVazio(Cliente c);
Iterador iteradorProdutosCestoCliente (Cliente c);

// Operações universais
void destroiCliente(Cliente c);
void destroiTudoCliente(Cliente c);

#endif
