#include "Stock.h"

struct Stock{
    Sequencia produtos;
    Info info;
};

Stock criaStock(){
 Stock st= malloc(sizeof(struct Stock));
 if (st == NULL) semMemoria();
 st->produtos=criaSequencia();
 if (st->produtos == NULL) {
    free(st);
    semMemoria();
 }
 st->info = criaInfo("Stock", destroiStock, destroiTudoStock,
                    NULL, NULL, NULL);
 if (st->info == NULL) {
    destroiSequencia(st->produtos);
    free(st);
    semMemoria();
 }
 return st;
}

int reabastecerStock(Stock st, string nome, int quant){
  Iterador it= iteradorSequencia(st->produtos);
   while(temSeguinteIterador(it)){
    Produto p=seguinteIterador(it);
     if(strcmp(nomeProduto(p),nome)==0){
        alterarquantidadeProduto(p,quant);
        return 1;
       }
   }
 destroiIterador(it);
 return 0;
}

void destroiStock(Stock st) {
    if (st == NULL) return;
    destroiSequencia(st->produtos);
    free(st);
}

void destroiTudoStock(Stock st) {
    if (st == NULL) return;

    // Destruir cada produto individualmente
    Iterador it = iteradorSequencia(st->produtos);
    while (temSeguinteIterador(it)) {
        Produto p = seguinteIterador(it);
        destroiProduto(p);
    }
    destroiIterador(it);

    // Destruir a sequência
    destroiSequencia(st->produtos);

    // Destruir o stock
    free(st);
}

Iterador iteradorProdutosStock(Stock st){
  return iteradorSequencia(st->produtos);
}

Produto produtoNovoStock(Stock st, Produto p){
   Iterador it= iteradorSequencia(st->produtos);
   while(temSeguinteIterador(it)){
    Produto prod=seguinteIterador(it);
      if (strcmp(nomeProduto(prod), nomeProduto(p)) == 0){
        destroiIterador(it);
        destroiProduto(p);
        return NULL; //Produto já existe
      }
   }
    destroiIterador(it);
    acrescentaSequencia(st->produtos,p);
    return p;
}

 //Função para obter Produto na sequencia de produtos "Stock" pelo nome
Produto produtoStockPorNome(Stock s, string nome) {
    Iterador it = iteradorSequencia(s->produtos);
    while (temSeguinteIterador(it)) {
        Produto p = seguinteIterador(it);
        if (strcmp(nomeProduto(p), nome) == 0) {
            destroiIterador(it);
            return p;
        }
    }
    destroiIterador(it);
    return NULL;
}
