#include "Sequencia.h"
#include "Produto.h"
#include <stdio.h>
#include <string.h>

int main() {
    printf("Iniciando teste...\n");
    
    // Criar uma sequência
    Sequencia s = criaSequencia();
    if (s == NULL) {
        printf("Erro ao criar sequência\n");
        return 1;
    }
    
    printf("Criando produtos...\n");
    
    // Criar alguns produtos
    Produto p1 = criaProduto("banana", 5, 100, 200);
    if (p1 == NULL) {
        printf("Erro ao criar produto 1\n");
        return 1;
    }
    
    Produto p2 = criaProduto("abacaxi", 3, 200, 500);
    if (p2 == NULL) {
        printf("Erro ao criar produto 2\n");
        destroiProduto(p1);
        return 1;
    }
    
    Produto p3 = criaProduto("laranja", 4, 150, 300);
    if (p3 == NULL) {
        printf("Erro ao criar produto 3\n");
        destroiProduto(p1);
        destroiProduto(p2);
        return 1;
    }
    
    printf("Adicionando produtos à sequência...\n");
    
    // Adicionar produtos à sequência
    acrescentaSequencia(s, p1);
    acrescentaSequencia(s, p2);
    acrescentaSequencia(s, p3);
    
    printf("Produtos na ordem original:\n");
    Iterador it1 = iteradorSequencia(s);
    if (it1 == NULL) {
        printf("Erro ao criar iterador 1\n");
        destroiTudoSequencia(s);
        return 1;
    }
    
    while (temSeguinteIterador(it1)) {
        Produto p = seguinteIterador(it1);
        if (p == NULL) {
            printf("Erro: produto NULL encontrado\n");
            break;
        }
        printf("Produto: %s\n", nomeProduto(p));
    }
    destroiIterador(it1);
    
    printf("\nTentando ordenar produtos...\n");
    
    // Ordenar produtos manualmente
    int tamanho = tamanhoSequencia(s);
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = 0; j < tamanho - i - 1; j++) {
            Produto p1 = (Produto)elementoSequencia(s, j);
            Produto p2 = (Produto)elementoSequencia(s, j + 1);
            
            if (p1 == NULL || p2 == NULL) {
                printf("Erro: produto NULL encontrado durante ordenação\n");
                destroiTudoSequencia(s);
                return 1;
            }
            
            if (strcmp(nomeProduto(p1), nomeProduto(p2)) > 0) {
                atribuiSequencia(s, p2, j);
                atribuiSequencia(s, p1, j + 1);
            }
        }
    }
    
    printf("\nProdutos ordenados:\n");
    Iterador it2 = iteradorSequencia(s);
    if (it2 == NULL) {
        printf("Erro ao criar iterador 2\n");
        destroiTudoSequencia(s);
        return 1;
    }
    
    while (temSeguinteIterador(it2)) {
        Produto p = seguinteIterador(it2);
        if (p == NULL) {
            printf("Erro: produto NULL encontrado\n");
            break;
        }
        printf("Produto: %s\n", nomeProduto(p));
    }
    destroiIterador(it2);
    
    printf("\nLimpando memória...\n");
    
    // Destruir produtos manualmente
    destroiProduto(p1);
    destroiProduto(p2);
    destroiProduto(p3);
    
    // Destruir sequência
    destroiSequencia(s);
    
    printf("Teste concluído com sucesso!\n");
    
    return 0;
} 