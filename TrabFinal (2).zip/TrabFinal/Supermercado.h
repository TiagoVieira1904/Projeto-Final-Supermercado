#include "Stock.h"
#include "Produto.h"
#include "Cliente.h"
#ifndef SUPERMERCADO_H
#define SUPERMERCADO_H
typedef struct Supermercado *Supermercado;

Supermercado criaSupermercado();
Iterador iteradorProdutosSupermercado(Supermercado s);
void destroiTudoSupermercado(Supermercado s);
int reabastecerStockSupermercado(Supermercado s, string nome, int quant);
Produto produtoNovoSupermercado(Supermercado s,string nome, int quantidade, unsigned int preco, unsigned int peso);
Iterador iteradorClientesSupermercado(Supermercado s);
Iterador iteradorProdutosCestoClienteSupermercado(Supermercado s, Cliente c);
bool clienteTemCestoVazioSupermercado(Supermercado s, Cliente c);
Cliente clienteNovoSupermercado(Supermercado s);
bool adicionaCestoSupermercado(Supermercado s,int numCliente, string nomeProd, int quantidade);
Cliente clienteSupermercadoPorNumero(Supermercado s, int numCliente);

// Operações universais
void destroiSupermercado(Supermercado s);

#endif
