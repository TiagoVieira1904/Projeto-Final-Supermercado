#include "Produto.h"

struct Produto{
    string nome;
    int quantidade;
    unsigned int preco;
    unsigned int peso;
    Info info;
};

Produto criaProduto(string nome,int quant,unsigned int prec, unsigned int peso){
 if (peso == 0) {
        return NULL;
    }
 Produto p= malloc(sizeof(struct Produto));
 if (p == NULL) semMemoria();
 p->nome= malloc(strlen(nome)+1);
 if (p->nome == NULL) {
    //free(p);
    semMemoria();
 }
 strcpy(p->nome,nome);
 p->quantidade=quant;
 p->preco=prec;
 p->peso=peso;
 p->info = criaInfo("Produto", destroiProduto, destroiProduto,
                   comparaProdutos, NULL, NULL);
 if (p->info == NULL) {
    free(p->nome);
    free(p);
    semMemoria();
 }
 return p;
}

Produto alterarquantidadeProduto(Produto p, int quant){
 p->quantidade = p->quantidade+quant;
 return p;
}

Produto definirQuantidadeProduto(Produto p, int quant) {
    p->quantidade = quant;
    return p;
}

int quantidadeProduto(Produto p){
 return p->quantidade;
}

unsigned int precoProduto(Produto p){
 return p->preco;
}

unsigned int pesoProduto(Produto p){
    return p->peso;
}

string nomeProduto(Produto p){
 return p->nome;
}

// Função de comparação para ordenar produtos pelo nome
int comparaProdutos(Produto p1, Produto p2) {
    if (p1 == NULL || p2 == NULL) return 0;
    return strcmp(nomeProduto(p1), nomeProduto(p2));
}

void destroiProduto(Produto p){
  if (p != NULL) {
        if (p->nome != NULL) {
            free(p->nome);
        }
        free(p);
    }
}
