#include "Supermercado.h"
struct Supermercado{
    Stock stock;
    Sequencia clientes;
    Info info;
};

Supermercado criaSupermercado(){
 Supermercado s= malloc(sizeof(struct Supermercado));
 if(s==NULL) semMemoria();
 s->stock=criaStock();
 s->clientes=criaSequencia();
 if(s->clientes == NULL) {
    //destroiTudoStock(s->stock);
    //free(s);
    semMemoria();
 }
 s->info = criaInfo("Supermercado", destroiSupermercado, destroiTudoSupermercado,
                   NULL, NULL, NULL);
 if (s->info == NULL) {
    destroiTudoStock(s->stock);
    destroiSequencia(s->clientes);
    free(s);
    semMemoria();
 }
 return s;
}

//Para cmd 'R'
Iterador iteradorProdutosSupermercado(Supermercado s) {
    return iteradorProdutosStock(s->stock);
}

//Para cmd 'Q'
int reabastecerStockSupermercado(Supermercado s, string nome, int quant){
 return reabastecerStock(s->stock,nome,quant);
}

//Para cmd 'P'
Produto produtoNovoSupermercado(Supermercado s,string nome, int quantidade, unsigned int preco, unsigned int peso){
  Produto p=criaProduto(nome, quantidade, preco, peso);
  if (p == NULL) return NULL;
  return produtoNovoStock(s->stock,p);
}

//Para cmd 'E'
Iterador iteradorClientesSupermercado(Supermercado s){
 return iteradorSequencia(s->clientes);
}

//Para cmd 'E'
Iterador iteradorProdutosCestoClienteSupermercado(Supermercado s, Cliente c) {
    if (s == NULL || c == NULL)
        return NULL;

    // Verificar se o cliente existe no supermercado
    Iterador it = iteradorSequencia(s->clientes);
    bool clienteExiste = false;

    while (temSeguinteIterador(it)) {
        Cliente cl = seguinteIterador(it);
        if (obterNumCliente(cl) == obterNumCliente(c)) {
            clienteExiste = true;
            break;
        }
    }
    destroiIterador(it);

    if (!clienteExiste) {
        return NULL;
    }
    return iteradorProdutosCestoCliente(c);
}

//Para cmd 'E'
bool clienteTemCestoVazioSupermercado(Supermercado s, Cliente c){
 if (c == NULL)
        return false;
    return clienteTemCestoVazio(c);
}


//Para cmd 'C'
Cliente clienteNovoSupermercado(Supermercado s){
  Cliente c=criaCliente();
  if(c==NULL) semMemoria();
  acrescentaSequencia(s->clientes,c);
  return c;
}

//Para cmd 'D'
bool adicionaCestoSupermercado(Supermercado s, int numCliente, string nomeProd, int quantidade) {
    Cliente c = clienteSupermercadoPorNumero(s, numCliente);
    if (c == NULL) {
        return false;
    }
    Produto p = produtoStockPorNome(s->stock, nomeProd);
    if (p == NULL) {
        return false;
    }

    if (quantidade > quantidadeProduto(p)) {
        return false;
    }

    if (!reabastecerStock(s->stock, nomeProd, -quantidade)) {
        return false;
    }
    adicionarProdutoCesto(c, p, quantidade);
    return true;
}
//Para cmd 'D'
int obterQuantidadeCestoClienteSupermercado(Supermercado s,Cliente c,Produto p){
  return obterQuantidadeCestoCliente(c,p);
}


//Função para obter cliente na sequencia de clientes atraves do nº
Cliente clienteSupermercadoPorNumero(Supermercado s, int numCliente) {
    if (s == NULL || s->clientes == NULL){
        return NULL;}
    Iterador it = iteradorSequencia(s->clientes);
      if (it == NULL) {
        return NULL;
    }
    while (temSeguinteIterador(it)) {
        Cliente c = seguinteIterador(it);
        if (obterNumCliente(c) == numCliente) {
            destroiIterador(it);
            return c;
        }
    }
    destroiIterador(it);
    return NULL;
}

//Operações universais
void destroiSupermercado(Supermercado s) {
    if (s == NULL) return;
    destroiStock(s->stock);
    destroiSequencia(s->clientes);
    free(s);
}

void destroiTudoSupermercado(Supermercado s) {
    if (s == NULL) return;
    destroiTudoStock(s->stock);
    destroiTudoSequencia(s->clientes);
    free(s);
}

