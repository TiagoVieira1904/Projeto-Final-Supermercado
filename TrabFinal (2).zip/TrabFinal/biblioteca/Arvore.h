/*
 * Arvore.h
 */

#ifndef ARVORE_H
#define ARVORE_H

#include "Util.h"
#include "Info.h"
#include "Vetor.h"

/***********************************************
	Modulo Arvore - Arvores binarias genericas (nao e' TAD)
***********************************************/

/*------------------------------------------*/
/* Tipo publico */

typedef struct noArvore {
	obj elem;
	struct noArvore *esq, *dir;	// tipo recursivo
} *arvore;

/*------------------------------------------*/
/* Prototipos das funcoes publicas */

/***********************************************
criaNoArvore - Cria um no de arvore binaria.
Parametros:
	elem - o elemento guardado
	esq, dir - as subarvorees esquerda e direita
Retorno: o no' criado
Precondicao: elem != NULL (dir e esq pode ser NULL)
***********************************************/
arvore criaNoArvore(obj elem, arvore esq, arvore dir);

/***********************************************
destroiNoArvore - Elimina o no' apontado por a.
Parametros: a - apontador para o no' a eliminar
	(nao elimina a arvore completa)
Retorno: nada
Precondicao: a != NULL
***********************************************/
void destroiNoArvore(arvore a);

/***********************************************
destroiArvore - Elimina todos os nos da arvore,
	mas nao os elementos la' guardados.
Parametros: a - arvore
Retorno: nada
Precondicao: nada (a pode ser NULL)
***********************************************/
void destroiArvore(arvore a);

/***********************************************
destroiTudoArvore - Elimina todos os nos da lista,
	mais os elementos la' guardados.
Parametros: a - arvore
Retorno: nada
Precondicao: nada (a pode ser NULL)
***********************************************/
void destroiTudoArvore(arvore a);

/***********************************************
textoArvore - Converte em texto, para mostrar em situacoes de debug.
Parametros: a - arvore
Retorno: o texto criado
Precondicao: nada
***********************************************/
string textoArvore(arvore a);

/***********************************************
vaziaArvore - Testa se a arvore esta vazia.
Parametros: a - arvore
Retorno: true - se arvore vazia; false - caso contrario
Precondicao: nada
***********************************************/
bool vaziaArvore(arvore a);

/***********************************************
tamanhoArvore - Numero de elementos na arvore.
Parametros: a - arvore
Retorno: numero de elementos
Precondicao: nada
***********************************************/
int tamanhoArvore(arvore a);

/***********************************************
vetorArvore - Converte arvore para vetor (percurso prefixo).
Parametros:
	a - arvore
	n - saida do tamanho do vetor
Retorno: vetor
Precondicao: nada
***********************************************/
vetor vetorArvore(arvore a, int *n);

/***********************************************
testeArvore - Alguns testes simples.
***********************************************/
void testeArvore(void);

#endif /* ARVORE_H */
