#include "Util.h"
#include "Info.h"

#ifndef PRODUTO_H
#define PRODUTO_H
typedef struct Produto *Produto;

Produto criaProduto(string nome,int quant,unsigned int prec, unsigned int peso);
Produto alterarquantidadeProduto(Produto p, int quant);
Produto definirQuantidadeProduto(Produto p, int quant);
int quantidadeProduto(Produto p);
void destroiProduto(Produto p);
string nomeProduto(Produto p);
unsigned int precoProduto(Produto p);
unsigned int pesoProduto(Produto p);
#endif
