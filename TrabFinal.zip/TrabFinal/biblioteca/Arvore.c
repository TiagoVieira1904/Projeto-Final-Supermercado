/*
 * Arvore.c
 */

#include "Arvore.h"

/*------------------------------------------*/
/* Funcoes privadas */

static void textoArvoreAux(arvore a, string str, int tab){
	if (!vaziaArvore(a)){
		sprintf(str, "%*s", tab * 2, ""); str += strlen(str);
		sprintf(str, "%s\n", texto(a->elem)); str += strlen(str);
		textoArvoreAux(a->esq, str, tab+1); str += strlen(str);
		textoArvoreAux(a->dir, str, tab+1);
	}
}


static int vetorArvoreAux(arvore a, vetor v, int i){
	if (vaziaArvore(a))
		return i;
	else {
		v[i] = a->elem;
		int j = vetorArvoreAux(a->esq, v, i+1);
		return vetorArvoreAux(a->dir, v, j);
	}
}

/*------------------------------------------*/
/* Funcoes publicas */

arvore criaNoArvore(obj elem, arvore esq, arvore dir){
	arvore n = malloc(sizeof(struct noArvore));
	if (n == NULL) semMemoria();
	n->elem = elem;
	n->esq = esq;
	n->dir = dir;
	return n;
}

void destroiNoArvore(arvore a){
	free(a); // apenas o no' apontado
}

void destroiArvore(arvore a){
	destroiArvore(a->esq);
	destroiArvore(a->dir);
	destroiNoArvore(a);
}

void destroiTudoArvore(arvore a){
	destroiArvore(a->esq);
	destroiArvore(a->dir);
	destroiTudo(a->elem);
	destroiNoArvore(a);
}

string textoArvore(arvore a){
	string str = criaStringN(10000);
	textoArvoreAux(a, str, 1);
	return recriaString(str);
}

bool vaziaArvore(arvore a){
	return a == NULL;
}

int tamanhoArvore(arvore a){
	if (a == NULL)
		return 0;
	else
		return 1 + tamanhoArvore(a->esq) + tamanhoArvore(a->dir);
}

vetor vetorArvore(arvore a, int *n){
	*n = tamanhoArvore(a);
	vetor v = malloc(sizeof(obj) * *n);
	if (v == NULL) semMemoria();
	vetorArvoreAux(a, v, 0);
	return v;
}


#include "Int.h"

static arvore criaIntsArvore(int n){
	if (n == 0)
		return NULL;
	else
		return criaNoArvore(criaInt(n), criaIntsArvore(n-1), criaIntsArvore(n-1));
}

void testeArvore(void){
	arvore a = criaIntsArvore(3);
	printf("tamanho %d\n", tamanhoArvore(a));
	printf("%s\n", textoArvore(a));
	int n;
	vetor v = vetorArvore(a, &n);
	printf("%s\n", textoVetor(v, n));
}
