#include "Produto.h"

struct Produto{
    string nome;
    int quantidade;
    unsigned int preco;
    unsigned int peso;
};

Produto criaProduto(string nome,int quant,unsigned int prec, unsigned int peso){
 if (peso == 0) {
        return NULL;
    }
 Produto p= malloc(sizeof(struct Produto));
 if (p == NULL) semMemoria();
 p->nome= malloc(strlen(nome)+1);
 if (p->nome == NULL) semMemoria();
 strcpy(p->nome,nome);
 p->quantidade=quant;
 p->preco=prec;
 p->peso=peso;
 return p;
}

Produto alterarquantidadeProduto(Produto p, int quant){
 p->quantidade = p->quantidade+quant;
 return p;
}

Produto definirQuantidadeProduto(Produto p, int quant) {
    p->quantidade = quant;
    return p;
}

int quantidadeProduto(Produto p){
 return p->quantidade;
}

unsigned int precoProduto(Produto p){
 return p->preco;
}

unsigned int pesoProduto(Produto p){
    return p->peso;
}

string nomeProduto(Produto p){
 return p->nome;
}

void destroiProduto(Produto p){
 //destroi(p);
 //free(p);
  if (p != NULL) {
        if (p->nome != NULL) {
            free(p->nome);
        }
        free(p);
    }
}
