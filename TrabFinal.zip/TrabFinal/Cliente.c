#include "Cliente.h"

struct Cliente {
    int numCliente;
    Sequencia cestoProdutos;
};

Cliente criaCliente() {
    static int numeroCliente = 0;
    Cliente c = malloc(sizeof(struct Cliente));
    if (c == NULL) semMemoria();
    c->cestoProdutos = criaSequencia();
    if (c->cestoProdutos == NULL) {
        free(c);
        semMemoria();
    }
    c->numCliente = numeroCliente;
    numeroCliente++;
    return c;
}

void adicionarProdutoCesto(Cliente c, Produto p, int quantidade) {
    if (c == NULL || p == NULL) {
        semMemoria();
        return;
    }

    // Procurar se o produto já existe no cesto
    Iterador it = iteradorSequencia(c->cestoProdutos);
    Produto pExistente = NULL;

    while (temSeguinteIterador(it)) {
        Produto pCesto = seguinteIterador(it);
        if (strcmp(nomeProduto(pCesto), nomeProduto(p)) == 0) {
            pExistente = pCesto;
            break;
        }
    }
    destroiIterador(it);

    if (pExistente != NULL) {
        // O produto já existe, atualizar a quantidade
        int novaQuantidade = quantidadeProduto(pExistente) + quantidade;
        definirQuantidadeProduto(pExistente, novaQuantidade);
    } else {
        // Produto não existe, criar uma cópia e adicionar
        Produto pCopia = criaProduto(nomeProduto(p), quantidade, precoProduto(p), pesoProduto(p));
        if (pCopia == NULL) {
            semMemoria();
            return;
        }
        acrescentaSequencia(c->cestoProdutos, pCopia);
    }
}

//Obter quantidade de produto no cesto do cliente
int obterQuantidadeCestoCliente(Cliente c, Produto p) {
    if (c == NULL || p == NULL)
        return 0;

    Iterador it = iteradorSequencia(c->cestoProdutos);
    while (temSeguinteIterador(it)) {
        Produto pCesto = seguinteIterador(it);
        if (strcmp(nomeProduto(pCesto), nomeProduto(p)) == 0) {
            int qtd = quantidadeProduto(pCesto);
            destroiIterador(it);
            return qtd;
        }
    }
    destroiIterador(it);
    return 0;
}

int obterNumCliente(Cliente c){             //Obter numero do cliente
 return c->numCliente;
}

bool clienteTemCestoVazio(Cliente c) {
    return vaziaSequencia(c->cestoProdutos);
}

// Função de comparação para ordenar produtos pelo nome
int comparaProdutos(Produto p1, Produto p2) {
    return strcmp(nomeProduto(p1), nomeProduto(p2));
}

Iterador iteradorProdutosCestoCliente(Cliente c) {
    if (c == NULL || c->cestoProdutos == NULL) {
        return NULL;
    }
    return iteradorOrdenadoSequencia(c->cestoProdutos);
}
